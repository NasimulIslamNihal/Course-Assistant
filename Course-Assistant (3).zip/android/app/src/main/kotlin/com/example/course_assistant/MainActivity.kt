package com.example.course_assistant

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
